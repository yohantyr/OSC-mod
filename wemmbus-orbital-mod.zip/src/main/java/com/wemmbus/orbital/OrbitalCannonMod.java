package com.wemmbus.orbital;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public class OrbitalCannonMod implements ModInitializer {
    public static final String MOD_ID = "wemmbus_orbital";

    public static Item NUKE_ROD;
    public static Item STAB_ROD;

    @Override
    public void onInitialize() {
        NUKE_ROD = register("nuke_rod", StrikeType.NUKE);
        STAB_ROD = register("stab_rod", StrikeType.STAB);

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(NUKE_ROD);
            entries.accept(STAB_ROD);
        });

        StrikeManager.init();
    }

    private static Item register(String name, StrikeType type) {
        ResourceKey<Item> key = ResourceKey.create(
                Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, name));

        Item.Properties props = new Item.Properties()
                .setId(key)
                .durability(64)                       // fishing-rod style durability bar
                .rarity(Rarity.EPIC)
                .component(DataComponents.DAMAGE, 63); // 63 of 64 used = 1 durability left

        return Registry.register(BuiltInRegistries.ITEM, key, new OrbitalCannonItem(props, type));
    }
}
