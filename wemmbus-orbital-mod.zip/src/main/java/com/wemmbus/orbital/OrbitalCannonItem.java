package com.wemmbus.orbital;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

public class OrbitalCannonItem extends Item {
    private final StrikeType type;

    public OrbitalCannonItem(Properties properties, StrikeType type) {
        super(properties);
        this.type = type;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack stack = player.getItemInHand(hand);
        HitResult hit = player.pick(OrbitalConfig.RANGE, 1.0F, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            player.displayClientMessage(Component.literal("No target in range"), true);
            return InteractionResult.FAIL;
        }

        // Lock-on chirp for the shooter
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT,
                SoundSource.PLAYERS, 1.0F * OrbitalConfig.VOLUME, 1.7F);
        StrikeManager.schedule(serverLevel, hit.getLocation(), type, player.getDisplayName());
        // The rod breaks on use, in every game mode (shrink ignores creative)
        stack.shrink(1);
        return InteractionResult.SUCCESS;
    }
}
