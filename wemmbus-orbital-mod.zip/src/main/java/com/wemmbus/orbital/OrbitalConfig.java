package com.wemmbus.orbital;

/** Tweak these numbers, rebuild, and you're done. */
public final class OrbitalConfig {
    private OrbitalConfig() {}

    // --- General ---
    /** How far you can aim, in blocks. */
    public static final double RANGE = 160.0;
    /** Delay between right-click and the strike, in ticks (10 = 0.5s). */
    public static final int DELAY_TICKS = 10;

    // --- Effects ---
    /** Players within this many blocks of the target see the big title text and hear the warning. */
    public static final double ANNOUNCE_RADIUS = 256.0;
    /** Also post "X called in a NUKE shot at ..." in chat for everyone on the server. */
    public static final boolean BROADCAST_CHAT = true;

    // --- Damage ---
    /**
     * true  = TNT explosion damage is blocked near a strike and every living thing in the blast
     *         zone takes exactly STRIKE_DAMAGE instead (armor and enchantments still apply).
     * false = normal vanilla TNT damage (hundreds of TNT will kill almost anything).
     */
    public static final boolean CUSTOM_DAMAGE = true;
    /**
     * Raw damage before armor. 50.56 works out to 11 HP (5.5 hearts) for a player in full
     * netherite (armor 20, toughness 12) with Protection IV on all four pieces.
     * Unarmored or weaker-armored targets take much more.
     */
    public static final float STRIKE_DAMAGE = 50.56F;
    /** Nuke damage zone = outer ring radius + this many blocks. */
    public static final double NUKE_DAMAGE_PADDING = 2.0;
    /** Stab damage zone radius around the column, in blocks. */
    public static final double STAB_DAMAGE_RADIUS = 4.0;

    // --- Visuals and sound ---
    /** Multiplies every sound's volume. 1.0 = default, 0.5 = quieter. */
    public static final float VOLUME = 1.0F;
    /** Expanding shockwave ring after impact. */
    public static final boolean SHOCKWAVE = true;
    /** Rising mushroom cloud after the nuke. */
    public static final boolean MUSHROOM_CLOUD = true;
    /** Visual-only lightning bolts on impact (no fire, no damage). */
    public static final boolean LIGHTNING_FX = true;
    /** How long the nuke aftermath effects run, in ticks. */
    public static final int AFTERMATH_TICKS = 50;

    // --- Nuke ---
    /** Number of concentric rings of TNT. */
    public static final int NUKE_RINGS = 10;
    /** Distance between rings, in blocks. */
    public static final double NUKE_RING_STEP = 3.0;
    /** Rough gap between TNT along a ring. Lower = more TNT (and more lag). */
    public static final double NUKE_ARC_SPACING = 1.6;
    /** How high above the target the TNT starts, in blocks. */
    public static final double NUKE_HEIGHT = 40.0;
    /** Hard cap on TNT per nuke. With the defaults you get roughly 650. */
    public static final int NUKE_MAX_TNT = 700;

    // --- Stab ---
    /** Gap between TNT in the column, in blocks. */
    public static final double STAB_STEP = 2.0;
    /** How many TNT are placed per tick as the stab drills down. */
    public static final int STAB_TNT_PER_TICK = 4;
}
