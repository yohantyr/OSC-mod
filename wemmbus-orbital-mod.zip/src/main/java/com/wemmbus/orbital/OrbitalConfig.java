package com.wemmbus.orbital;

/** Tweak these numbers, rebuild, and you're done. */
public final class OrbitalConfig {
    private OrbitalConfig() {}

    // --- General ---
    /** How far you can aim, in blocks. */
    public static final double RANGE = 160.0;
    /** Delay between right-click and the strike, in ticks (10 = 0.5s). */
    public static final int DELAY_TICKS = 10;
    /** Cooldown between shots, in ticks (20 ticks = 1 second). */
    public static final int COOLDOWN_TICKS = 40;

    // --- Effects ---
    /** Players within this many blocks of the target see the big title text and hear the warning. */
    public static final double ANNOUNCE_RADIUS = 256.0;
    /** Also post "X called in a NUKE shot at ..." in chat for everyone on the server. */
    public static final boolean BROADCAST_CHAT = true;

    // --- Nuke ---
    /** Number of concentric rings of TNT. */
    public static final int NUKE_RINGS = 10;
    /** Distance between rings, in blocks. */
    public static final double NUKE_RING_STEP = 3.0;
    /** Rough gap between TNT along a ring. Lower = more TNT (and more lag). */
    public static final double NUKE_ARC_SPACING = 1.6;
    /** How high above the target the TNT starts, in blocks. */
    public static final double NUKE_HEIGHT = 40.0;
    /** Hard cap on TNT per nuke. With the defaults you get roughly 650. */
    public static final int NUKE_MAX_TNT = 700;

    // --- Stab ---
    /** Gap between TNT in the column, in blocks. */
    public static final double STAB_STEP = 2.0;
    /** How many TNT are placed per tick as the stab drills down. */
    public static final int STAB_TNT_PER_TICK = 4;
}
