package com.wemmbus.orbital;

public enum StrikeType {
    /** Rings of TNT dropped from the sky, detonating together. */
    NUKE,
    /** A column of TNT drilling straight down. */
    STAB
}
