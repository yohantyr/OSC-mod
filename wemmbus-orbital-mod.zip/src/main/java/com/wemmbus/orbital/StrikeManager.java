package com.wemmbus.orbital;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.phys.Vec3;

/** Runs every active strike once per server tick. */
public final class StrikeManager {
    private static final List<Strike> ACTIVE = new ArrayList<>();

    private StrikeManager() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> ACTIVE.clear());
    }

    public static void schedule(ServerLevel level, Vec3 pos, StrikeType type, Component shooter) {
        ACTIVE.add(new Strike(level, pos, type, shooter));
    }

    private static void tick() {
        Iterator<Strike> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            s.tick();
            if (s.done) {
                it.remove();
            }
        }
    }

    /** How many ticks a TNT takes to fall `height` blocks from rest (matches vanilla gravity and drag). */
    static int fallTicks(double height) {
        double vy = 0, dist = 0;
        int t = 0;
        while (dist < height && t < 400) {
            vy -= 0.04;
            dist += -vy;
            vy *= 0.98;
            t++;
        }
        return Math.max(t, 1);
    }

    /** Big on-screen text for everyone near the target. */
    static void sendTitle(ServerLevel level, Vec3 center, Component title, Component subtitle,
                          int fadeIn, int stay, int fadeOut) {
        double r2 = OrbitalConfig.ANNOUNCE_RADIUS * OrbitalConfig.ANNOUNCE_RADIUS;
        ClientboundSetTitlesAnimationPacket timing = new ClientboundSetTitlesAnimationPacket(fadeIn, stay, fadeOut);
        ClientboundSetSubtitleTextPacket sub = new ClientboundSetSubtitleTextPacket(subtitle);
        ClientboundSetTitleTextPacket main = new ClientboundSetTitleTextPacket(title);
        for (ServerPlayer p : level.players()) {
            if (p.position().distanceToSqr(center) <= r2) {
                p.connection.send(timing);
                p.connection.send(sub);
                p.connection.send(main);
            }
        }
    }

    private static final class Strike {
        final ServerLevel level;
        final Vec3 pos;
        final StrikeType type;
        final Component shooter;
        final int minY;
        final int maxY;
        int age = 0;
        int stabLayer = 0;
        int impactTick = -1;
        boolean done = false;

        Strike(ServerLevel level, Vec3 pos, StrikeType type, Component shooter) {
            this.level = level;
            this.pos = pos;
            this.type = type;
            this.shooter = shooter;
            this.minY = level.dimensionType().minY();
            this.maxY = minY + level.dimensionType().height() - 1;
        }

        void tick() {
            age++;

            if (age == 1) {
                announce();
            }

            if (age <= OrbitalConfig.DELAY_TICKS) {
                showMarker();
            }

            if (type == StrikeType.NUKE) {
                if (age == OrbitalConfig.DELAY_TICKS) {
                    spawnNuke();
                }
                if (impactTick > 0 && age == impactTick) {
                    nukeImpact();
                    done = true;
                }
            } else if (age >= OrbitalConfig.DELAY_TICKS) {
                stabTick();
            }
        }

        /** Warning text, siren sound and chat message the moment the cannon fires. */
        void announce() {
            BlockPos at = BlockPos.containing(pos);
            boolean nuke = type == StrikeType.NUKE;

            level.playSound(null, at, SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 4.0F, 0.6F);
            if (nuke) {
                level.playSound(null, at, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 8.0F, 0.8F);
            } else {
                level.playSound(null, at, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 8.0F, 1.3F);
            }

            Component title = Component.literal(nuke ? "NUKE SHOT INBOUND" : "STAB SHOT INBOUND")
                    .withStyle(nuke ? ChatFormatting.RED : ChatFormatting.AQUA, ChatFormatting.BOLD);
            Component subtitle = Component.literal(nuke ? "Take cover!" : "Nothing survives below")
                    .withStyle(ChatFormatting.GOLD);
            sendTitle(level, pos, title, subtitle, 2, 14, 6);

            if (OrbitalConfig.BROADCAST_CHAT) {
                MutableComponent msg = Component.empty()
                        .append(shooter)
                        .append(Component.literal(" called in a "))
                        .append(Component.literal(nuke ? "NUKE" : "STAB")
                                .withStyle(nuke ? ChatFormatting.RED : ChatFormatting.AQUA, ChatFormatting.BOLD))
                        .append(Component.literal(" shot at " + (int) pos.x + ", " + (int) pos.y + ", " + (int) pos.z));
                level.getServer().getPlayerList().broadcastSystemMessage(msg, false);
            }
        }

        /** Warning particles during the short delay. */
        void showMarker() {
            double x = pos.x, y = pos.y, z = pos.z;
            if (type == StrikeType.NUKE) {
                DustParticleOptions red = new DustParticleOptions(0xFF2020, 2.0F);
                double radius = OrbitalConfig.NUKE_RINGS * OrbitalConfig.NUKE_RING_STEP;
                for (int i = 0; i < 48; i++) {
                    double a = (Math.PI * 2 * i) / 48.0;
                    level.sendParticles(red, x + Math.cos(a) * radius, y + 0.2, z + Math.sin(a) * radius,
                            1, 0, 0, 0, 0);
                }
            } else {
                DustParticleOptions cyan = new DustParticleOptions(0x20D0FF, 2.0F);
                for (int i = 0; i < 16; i++) {
                    double a = (Math.PI * 2 * i) / 16.0;
                    level.sendParticles(cyan, x + Math.cos(a) * 2, y + 0.2, z + Math.sin(a) * 2,
                            1, 0, 0, 0, 0);
                }
                for (double h = 0; h <= 60; h += 2) {
                    level.sendParticles(ParticleTypes.END_ROD, x, y + h, z, 1, 0.1, 0, 0.1, 0.0);
                }
            }
        }

        /** Rings of TNT high above the target, timed so they all detonate on the same tick. */
        void spawnNuke() {
            double startY = Math.min(pos.y + OrbitalConfig.NUKE_HEIGHT, maxY - 2);
            int fuse = fallTicks(startY - pos.y);
            impactTick = age + fuse;
            int count = 0;

            spawnTnt(pos.x, startY, pos.z, fuse);
            count++;

            for (int ring = 1; ring <= OrbitalConfig.NUKE_RINGS; ring++) {
                double r = ring * OrbitalConfig.NUKE_RING_STEP;
                int n = Math.max(6, (int) Math.round(Math.PI * 2 * r / OrbitalConfig.NUKE_ARC_SPACING));
                double twist = ring * 0.3;
                for (int k = 0; k < n; k++) {
                    if (count >= OrbitalConfig.NUKE_MAX_TNT) {
                        return;
                    }
                    double a = (Math.PI * 2 * k) / n + twist;
                    spawnTnt(pos.x + Math.cos(a) * r, startY, pos.z + Math.sin(a) * r, fuse);
                    count++;
                }
            }
        }

        /** Extra flash and text when the nuke goes off. */
        void nukeImpact() {
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.x, pos.y + 2, pos.z, 12, 12, 2, 12, 0);
            sendTitle(level, pos,
                    Component.literal("DETONATION").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD),
                    Component.literal("Impact confirmed").withStyle(ChatFormatting.GRAY),
                    0, 10, 10);
        }

        /** Drills a column of instant TNT down from the target toward the bottom of the world. */
        void stabTick() {
            for (int i = 0; i < OrbitalConfig.STAB_TNT_PER_TICK; i++) {
                double y = pos.y + 1 - stabLayer * OrbitalConfig.STAB_STEP;
                if (y < minY) {
                    done = true;
                    return;
                }
                spawnTnt(pos.x, y, pos.z, 1);
                stabLayer++;
            }
        }

        void spawnTnt(double x, double y, double z, int fuse) {
            PrimedTnt tnt = EntityType.TNT.create(level, EntitySpawnReason.TRIGGERED);
            if (tnt == null) {
                return;
            }
            tnt.setPos(x, y, z);
            tnt.setDeltaMovement(Vec3.ZERO);
            tnt.setFuse(fuse);
            level.addFreshEntity(tnt);
        }
    }
}
