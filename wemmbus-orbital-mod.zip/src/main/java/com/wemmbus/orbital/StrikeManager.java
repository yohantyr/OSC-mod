package com.wemmbus.orbital;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Runs every active strike once per server tick. */
public final class StrikeManager {
    private static final List<Strike> ACTIVE = new ArrayList<>();
    /** True while our own damage is being applied, so the explosion filter lets it through. */
    private static boolean internalDamage = false;

    private StrikeManager() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> tick());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> ACTIVE.clear());

        // Block vanilla TNT damage near a strike so STRIKE_DAMAGE is the only damage dealt
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (internalDamage || !OrbitalConfig.CUSTOM_DAMAGE) {
                return true;
            }
            return !(source.is(DamageTypeTags.IS_EXPLOSION) && inActiveZone(entity));
        });
    }

    private static boolean inActiveZone(LivingEntity entity) {
        for (Strike s : ACTIVE) {
            if (s.level != entity.level()) {
                continue;
            }
            double dx = entity.getX() - s.pos.x;
            double dz = entity.getZ() - s.pos.z;
            double r = s.zoneRadius();
            if (dx * dx + dz * dz <= r * r) {
                return true;
            }
        }
        return false;
    }

    public static void schedule(ServerLevel level, Vec3 pos, StrikeType type, Component shooter) {
        ACTIVE.add(new Strike(level, pos, type, shooter));
    }

    private static void tick() {
        Iterator<Strike> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            s.tick();
            if (s.done) {
                it.remove();
            }
        }
    }

    /** How far a TNT has fallen from rest after `ticks` ticks (matches vanilla gravity and drag). */
    static double fallDistance(int ticks) {
        double vy = 0, dist = 0;
        for (int i = 0; i < ticks; i++) {
            vy -= 0.04;
            dist += -vy;
            vy *= 0.98;
        }
        return dist;
    }

    /** How many ticks a TNT takes to fall `height` blocks from rest. */
    static int fallTicks(double height) {
        double vy = 0, dist = 0;
        int t = 0;
        while (dist < height && t < 400) {
            vy -= 0.04;
            dist += -vy;
            vy *= 0.98;
            t++;
        }
        return Math.max(t, 1);
    }

    /** Big on-screen text for everyone near the target. */
    static void sendTitle(ServerLevel level, Vec3 center, Component title, Component subtitle,
                          int fadeIn, int stay, int fadeOut) {
        double r2 = OrbitalConfig.ANNOUNCE_RADIUS * OrbitalConfig.ANNOUNCE_RADIUS;
        ClientboundSetTitlesAnimationPacket timing = new ClientboundSetTitlesAnimationPacket(fadeIn, stay, fadeOut);
        ClientboundSetSubtitleTextPacket sub = new ClientboundSetSubtitleTextPacket(subtitle);
        ClientboundSetTitleTextPacket main = new ClientboundSetTitleTextPacket(title);
        for (ServerPlayer p : level.players()) {
            if (p.position().distanceToSqr(center) <= r2) {
                p.connection.send(timing);
                p.connection.send(sub);
                p.connection.send(main);
            }
        }
    }

    private static final class Strike {
        final ServerLevel level;
        final Vec3 pos;
        final StrikeType type;
        final Component shooter;
        final int minY;
        final int maxY;
        final double outerRadius = OrbitalConfig.NUKE_RINGS * OrbitalConfig.NUKE_RING_STEP;
        int age = 0;
        int stabLayer = 0;
        int dropAge = -1;
        double startY;
        int impactTick = -1;
        int finishedAge = -1;
        boolean done = false;

        Strike(ServerLevel level, Vec3 pos, StrikeType type, Component shooter) {
            this.level = level;
            this.pos = pos;
            this.type = type;
            this.shooter = shooter;
            this.minY = level.dimensionType().minY();
            this.maxY = minY + level.dimensionType().height() - 1;
        }

        // ---------------------------------------------------------------- main loop

        void tick() {
            age++;

            if (age == 1) {
                announce();
            }
            if (age <= OrbitalConfig.DELAY_TICKS) {
                showMarker();
                beep();
            }

            if (type == StrikeType.NUKE) {
                tickNuke();
            } else {
                tickStab();
            }
        }

        void tickNuke() {
            if (age == OrbitalConfig.DELAY_TICKS) {
                spawnNuke();
            }
            if (dropAge > 0 && age > dropAge && age < impactTick) {
                fallTrails();
            }
            if (impactTick > 0) {
                if (age == impactTick) {
                    nukeImpact();
                }
                if (age >= impactTick) {
                    aftermath(age - impactTick);
                }
                if (age >= impactTick + OrbitalConfig.AFTERMATH_TICKS) {
                    done = true;
                }
            }
        }

        void tickStab() {
            if (age == OrbitalConfig.DELAY_TICKS) {
                stabStart();
            }
            if (finishedAge > 0 && age >= finishedAge + 3) {
                done = true; // short grace so the last TNT's damage is still filtered
                return;
            }
            if (age >= OrbitalConfig.DELAY_TICKS) {
                int t = age - OrbitalConfig.DELAY_TICKS;
                if (OrbitalConfig.SHOCKWAVE && t <= 8) {
                    ring(ParticleTypes.CLOUD, pos.y + 0.5, 1.5 * t, 0.15);
                }
                drill();
            }
        }

        // ---------------------------------------------------------------- announce

        /** Warning text, siren sound and chat message the moment the cannon fires. */
        void announce() {
            boolean nuke = type == StrikeType.NUKE;

            sound(SoundEvents.BEACON_ACTIVATE, 4.0F, 0.6F);
            if (nuke) {
                sound(SoundEvents.WITHER_SPAWN, 8.0F, 0.8F);
            } else {
                sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 8.0F, 1.3F);
            }

            Component title = Component.literal(nuke ? "NUKE SHOT INBOUND" : "STAB SHOT INBOUND")
                    .withStyle(nuke ? ChatFormatting.RED : ChatFormatting.AQUA, ChatFormatting.BOLD);
            Component subtitle = Component.literal(nuke ? "Take cover!" : "Nothing survives below")
                    .withStyle(ChatFormatting.GOLD);
            sendTitle(level, pos, title, subtitle, 2, 14, 6);

            if (OrbitalConfig.BROADCAST_CHAT) {
                MutableComponent msg = Component.empty()
                        .append(shooter)
                        .append(Component.literal(" called in a "))
                        .append(Component.literal(nuke ? "NUKE" : "STAB")
                                .withStyle(nuke ? ChatFormatting.RED : ChatFormatting.AQUA, ChatFormatting.BOLD))
                        .append(Component.literal(" shot at " + (int) pos.x + ", " + (int) pos.y + ", " + (int) pos.z));
                level.getServer().getPlayerList().broadcastSystemMessage(msg, false);
            }
        }

        /** Rising countdown beeps during the delay. */
        void beep() {
            if (age % 3 == 2) {
                sound(SoundEvents.BEACON_POWER_SELECT, 3.0F, Math.min(0.8F + age * 0.08F, 2.0F));
            }
        }

        // ---------------------------------------------------------------- targeting marker

        /** Targeting laser and footprint during the short delay. */
        void showMarker() {
            double x = pos.x, y = pos.y, z = pos.z;
            if (type == StrikeType.NUKE) {
                DustParticleOptions red = new DustParticleOptions(0xFF2020, 2.0F);
                DustParticleOptions orange = new DustParticleOptions(0xFF8A00, 1.6F);
                // outer footprint + a ring sweeping outward from the center
                ring(red, y + 0.2, outerRadius, 0);
                double sweep = outerRadius * Math.min(1.0, (double) age / OrbitalConfig.DELAY_TICKS);
                ring(orange, y + 0.3, sweep, 0);
                // red targeting laser
                DustParticleOptions beam = new DustParticleOptions(0xFF3030, 1.5F);
                for (double h = 0; h <= 80; h += 2) {
                    level.sendParticles(beam, x, y + h, z, 1, 0.05, 0, 0.05, 0);
                }
            } else {
                DustParticleOptions cyan = new DustParticleOptions(0x20D0FF, 2.0F);
                ring(cyan, y + 0.2, 2.0, 0);
                ring(cyan, y + 0.3, 2.0 * (1.0 - (double) age / OrbitalConfig.DELAY_TICKS) + 0.3, 0);
                for (double h = 0; h <= 70; h += 2) {
                    level.sendParticles(ParticleTypes.END_ROD, x, y + h, z, 1, 0.08, 0, 0.08, 0.0);
                    level.sendParticles(cyan, x, y + h, z, 1, 0.1, 0, 0.1, 0.0);
                }
            }
        }

        // ---------------------------------------------------------------- nuke

        /** Rings of TNT high above the target, timed so they all detonate on the same tick. */
        void spawnNuke() {
            startY = Math.min(pos.y + OrbitalConfig.NUKE_HEIGHT, maxY - 2);
            int fuse = fallTicks(startY - pos.y);
            dropAge = age;
            impactTick = age + fuse;

            // Release effects: a ring of cloud in the sky and a falling whoosh
            ring(ParticleTypes.CLOUD, startY, outerRadius, 0.05);
            sound(SoundEvents.WARDEN_SONIC_CHARGE, 8.0F, 1.0F);

            int count = 0;
            spawnTnt(pos.x, startY, pos.z, fuse);
            count++;

            for (int ring = 1; ring <= OrbitalConfig.NUKE_RINGS; ring++) {
                double r = ring * OrbitalConfig.NUKE_RING_STEP;
                int n = Math.max(6, (int) Math.round(Math.PI * 2 * r / OrbitalConfig.NUKE_ARC_SPACING));
                double twist = ring * 0.3;
                for (int k = 0; k < n; k++) {
                    if (count >= OrbitalConfig.NUKE_MAX_TNT) {
                        return;
                    }
                    double a = (Math.PI * 2 * k) / n + twist;
                    spawnTnt(pos.x + Math.cos(a) * r, startY, pos.z + Math.sin(a) * r, fuse);
                    count++;
                }
            }
        }

        /** Fire and smoke trailing the falling TNT, sampled from each ring. */
        void fallTrails() {
            double y = startY - fallDistance(age - dropAge);
            for (int ring = 0; ring <= OrbitalConfig.NUKE_RINGS; ring++) {
                double r = ring * OrbitalConfig.NUKE_RING_STEP;
                for (int k = 0; k < 4; k++) {
                    double a = (Math.PI / 2) * k + ring * 0.3 + age * 0.15;
                    double px = pos.x + Math.cos(a) * r;
                    double pz = pos.z + Math.sin(a) * r;
                    level.sendParticles(ParticleTypes.FLAME, px, y + 1, pz, 1, 0.1, 0.3, 0.1, 0.01);
                    level.sendParticles(ParticleTypes.SMOKE, px, y + 2, pz, 1, 0.1, 0.5, 0.1, 0.01);
                }
            }
        }

        /** The moment the TNT goes off: sound, lightning, flash, and the DETONATION title. */
        void nukeImpact() {
            sound(SoundEvents.WARDEN_SONIC_BOOM, 10.0F, 0.5F);
            sound(SoundEvents.LIGHTNING_BOLT_THUNDER, 10.0F, 0.6F);

            if (OrbitalConfig.LIGHTNING_FX) {
                visualLightning(pos.x, pos.y, pos.z);
                for (int i = 0; i < 4; i++) {
                    double a = (Math.PI / 2) * i + Math.PI / 4;
                    visualLightning(pos.x + Math.cos(a) * outerRadius * 0.6, pos.y,
                            pos.z + Math.sin(a) * outerRadius * 0.6);
                }
            }

            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.x, pos.y + 2, pos.z, 12, 12, 2, 12, 0);

            damageEntities(outerRadius + OrbitalConfig.NUKE_DAMAGE_PADDING, pos.y - 8, pos.y + 20);

            sendTitle(level, pos,
                    Component.literal("DETONATION").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD),
                    Component.literal("Impact confirmed").withStyle(ChatFormatting.GRAY),
                    0, 10, 10);
        }

        /** Shockwave ring, then a rising stem and spreading cap. t = ticks since impact. */
        void aftermath(int t) {
            double x = pos.x, y = pos.y, z = pos.z;

            if (OrbitalConfig.SHOCKWAVE && t <= 15) {
                ring(ParticleTypes.CLOUD, y + 0.5, 4.0 * t, 0.2);
            }

            if (OrbitalConfig.MUSHROOM_CLOUD && t <= 40) {
                double h = t * 1.2;
                // stem
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y + h, z, 6, 1.5, 0.3, 1.5, 0.01);
                if (t < 25) {
                    level.sendParticles(ParticleTypes.FLAME, x, y + h, z, 6, 1.2, 0.3, 1.2, 0.03);
                }
                // cap
                if (t >= 12) {
                    double capR = Math.min(14.0, (t - 12) * 0.7 + 2.0);
                    ring(ParticleTypes.CAMPFIRE_COSY_SMOKE, y + h, capR, 0.01);
                    level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y + h + 1, z, 8,
                            capR * 0.5, 0.8, capR * 0.5, 0.02);
                }
            }
        }

        // ---------------------------------------------------------------- stab

        void stabStart() {
            sound(SoundEvents.WARDEN_SONIC_BOOM, 8.0F, 1.2F);
            sound(SoundEvents.LIGHTNING_BOLT_IMPACT, 6.0F, 1.0F);
            if (OrbitalConfig.LIGHTNING_FX) {
                visualLightning(pos.x, pos.y, pos.z);
            }
            level.sendParticles(ParticleTypes.SONIC_BOOM, pos.x, pos.y + 1, pos.z, 1, 0, 0, 0, 0);

            damageEntities(OrbitalConfig.STAB_DAMAGE_RADIUS, minY, pos.y + 8);
        }

        /** Drills a column of instant TNT down from the target toward the bottom of the world. */
        void drill() {
            if (finishedAge > 0) {
                return;
            }
            for (int i = 0; i < OrbitalConfig.STAB_TNT_PER_TICK; i++) {
                double y = pos.y + 1 - stabLayer * OrbitalConfig.STAB_STEP;
                if (y < minY) {
                    finishStab();
                    return;
                }
                spawnTnt(pos.x, y, pos.z, 1);
                level.sendParticles(ParticleTypes.END_ROD, pos.x, y, pos.z, 4, 0.3, 0.3, 0.3, 0.05);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, y, pos.z, 8, 0.8, 0.8, 0.8, 0.3);
                stabLayer++;
            }
            // Pitch climbs as the stab goes deeper
            level.playSound(null, BlockPos.containing(pos.x, pos.y - stabLayer * OrbitalConfig.STAB_STEP, pos.z),
                    SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE,
                    2.0F * OrbitalConfig.VOLUME, Math.min(0.6F + stabLayer * 0.015F, 2.0F));
        }

        void finishStab() {
            level.sendParticles(ParticleTypes.POOF, pos.x, pos.y + 1, pos.z, 30, 1.0, 0.5, 1.0, 0.1);
            level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y + 1, pos.z, 20, 1.0, 1.5, 1.0, 0.05);
            sound(SoundEvents.BEACON_DEACTIVATE, 4.0F, 1.0F);
            finishedAge = age;
        }

        // ---------------------------------------------------------------- helpers

        /** Deals STRIKE_DAMAGE to every living entity in the cylinder around the target. */
        void damageEntities(double radius, double yMin, double yMax) {
            if (!OrbitalConfig.CUSTOM_DAMAGE) {
                return;
            }
            AABB box = new AABB(pos.x - radius, yMin, pos.z - radius, pos.x + radius, yMax, pos.z + radius);
            DamageSource source = level.damageSources().explosion(null, null);
            internalDamage = true;
            try {
                for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box)) {
                    double dx = target.getX() - pos.x;
                    double dz = target.getZ() - pos.z;
                    if (dx * dx + dz * dz <= radius * radius) {
                        target.hurtServer(level, source, OrbitalConfig.STRIKE_DAMAGE);
                    }
                }
            } finally {
                internalDamage = false;
            }
        }

        /** Horizontal radius where vanilla TNT damage is blocked. */
        double zoneRadius() {
            return type == StrikeType.NUKE
                    ? outerRadius + OrbitalConfig.NUKE_DAMAGE_PADDING + 8
                    : OrbitalConfig.STAB_DAMAGE_RADIUS + 8;
        }

        /** Ring of particles at the target, at the given height and radius. */
        void ring(net.minecraft.core.particles.ParticleOptions particle, double y, double radius, double speed) {
            int pts = Math.max(16, (int) (radius * 2));
            for (int i = 0; i < pts; i++) {
                double a = (Math.PI * 2 * i) / pts;
                level.sendParticles(particle, pos.x + Math.cos(a) * radius, y, pos.z + Math.sin(a) * radius,
                        1, 0, 0.1, 0, speed);
            }
        }

        void sound(SoundEvent event, float volume, float pitch) {
            level.playSound(null, BlockPos.containing(pos), event, SoundSource.HOSTILE,
                    volume * OrbitalConfig.VOLUME, pitch);
        }

        void visualLightning(double x, double y, double z) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level, EntitySpawnReason.TRIGGERED);
            if (bolt != null) {
                bolt.setPos(x, y, z);
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
        }

        void spawnTnt(double x, double y, double z, int fuse) {
            PrimedTnt tnt = EntityType.TNT.create(level, EntitySpawnReason.TRIGGERED);
            if (tnt == null) {
                return;
            }
            tnt.setPos(x, y, z);
            tnt.setDeltaMovement(Vec3.ZERO);
            tnt.setFuse(fuse);
            level.addFreshEntity(tnt);
        }
    }
}
