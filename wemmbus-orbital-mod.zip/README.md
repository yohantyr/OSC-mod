# Wemmbus Orbital Strike Cannon (Fabric, Minecraft 1.21.11)

Two fishing-rod-style cannons inspired by the Unstable SMP orbital strike cannon. Right-click a block (up to 160 blocks away) to mark it. The rod is used up when you fire it, in every game mode, and the strike lands 0.5 seconds later.

- **Orbital Cannon: Nuke** - about 650 TNT in 10 concentric rings, dropped from 40 blocks up and timed to detonate on the same tick.
- **Orbital Cannon: Stab** - a column of instant TNT drilling down from the target toward the bottom of the world. Stops at blast-resistant blocks like obsidian.

Effects: when a cannon fires, everyone within 256 blocks gets a big title ("NUKE SHOT INBOUND" / "STAB SHOT INBOUND"), a warning sound plays at the target, and chat announces who fired it and where. The nuke also shows "DETONATION" when the TNT goes off. Turn the chat message off or change the radius in `OrbitalConfig.java`.

Get them: Creative inventory > Tools & Utilities, or
`/give @s wemmbus_orbital:nuke_rod` and `/give @s wemmbus_orbital:stab_rod`.

Warning: hundreds of TNT on one tick will lag, especially on servers. Lower the numbers in `OrbitalConfig.java` if needed. TNT still respects the `tntExplodes` game rule.

## Build
- GitHub Actions: push this repo, open the Actions tab, run the `build` workflow, download the `wemmbus-orbital-jar` artifact (use the jar without `-sources`).
- Locally: Java 21 + Gradle, then `gradle build`. Jar is in `build/libs/`.

## Install
Put the jar in `.minecraft/mods/` with Fabric Loader 0.18.1+ and Fabric API for 1.21.11.
